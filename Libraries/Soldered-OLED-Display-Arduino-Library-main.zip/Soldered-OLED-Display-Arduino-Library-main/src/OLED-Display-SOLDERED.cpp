/**
 **************************************************
 *
 * @file        OLED-Display-SOLDERED.cpp
 * @brief       Empty because all the code is in the Adafruit library
 *
 *
 * @copyright GNU General Public License v3.0
 * @authors     Zvonimir Haramustek for soldered.com
 ***************************************************/
